package com.example.demo.admin.service;

import java.util.List;

import com.example.demo.admin.model.AppAccount;

public interface AdminService 
{
	public boolean registerAccount(AppAccount appAccount);

	public String findByEmail(String emailId);
	
	public List<AppAccount> findAllAppAccounts();
	
	public boolean updateAccountSw(String accId,String activeSw);
	
    public AppAccount findByAccountId(String accId);
	
	public boolean editAppAccount(AppAccount accModel);
}
